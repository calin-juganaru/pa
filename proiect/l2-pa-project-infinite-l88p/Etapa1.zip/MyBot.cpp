#include "hlt/game.hpp"
#include "hlt/constants.hpp"
#include "hlt/log.hpp"

#include <fstream>
#include <random>
#include <ctime>
#include <vector>
#include <algorithm>

using namespace std;
using namespace hlt;

#define cmd(x) command_queue.push_back(x)

constexpr auto ALMOST_FULL = 835;
constexpr auto RATIO = 9;

auto cardinals = vector(begin(ALL_CARDINALS), end(ALL_CARDINALS));

int main(int argc, char* argv[])
{
    auto rand = mt19937(argc > 1 ? stoul(argv[1]) : time(nullptr));

    auto game = Game(); game.ready("Georgian");
    auto length = (int)game.game_map->cells.size();
    auto map = vector<vector<int>>(length, vector<int>(length));
    auto command_queue = vector<Command>();
    auto last_position = unordered_map<int, Position>();

    auto MAX_DROPOFFS = (length > 40) ? 2u : 1u;
    auto spawn_frequency = 2;
    auto avg_halite = 111;
    
    for (;;)
    {
        game.update_frame();
        auto me = game.me;
        auto& game_map = game.game_map;
        command_queue.clear();
        
        if (game.turn_number % spawn_frequency == 0
            && me->halite >= constants::SHIP_COST
            && !game_map->at(me->shipyard)->is_occupied()
            && game_map->is_safe(me->shipyard))
        {
            command_queue.push_back(me->shipyard->spawn());
        }
        
        if (game.turn_number % 100 == 1 && me->dropoffs.size() < MAX_DROPOFFS)
            if (!me->ships.empty() && me->halite > constants::DROPOFF_COST)
            {
                auto farthest_ship = me->ships.begin()->first;
                auto max_halite = 0;

                for (auto&& ship: me->ships)
                {
                    auto halites = 0;
                    for (auto&& x: {-3, -2, -1, 0, 1, 2, 3})
                        for (auto&& y: {-3, -2, -1, 0, 1, 2, 3})
                            halites += game_map->at(ship.second->position 
                                                 + Position(x, y))->halite;

                    if (halites > max_halite)
                    {
                        max_halite = halites;
                        farthest_ship = ship.first;
                    }
                }
                
                cmd(me->ships[farthest_ship]->make_dropoff());
                me->ships.erase(farthest_ship);
            }
        
        for (auto&& [id, ship]: me->ships)
        {
            if (last_position.find(id) == end(last_position))
            {
                last_position[id] = Position();
            }
            else 
            {
                if (ship->position == last_position[id])
                {
                    shuffle(begin(cardinals), end(cardinals), rand);
                    for (auto&& direction: cardinals)
                    {
                        auto new_position = ship->position.directional_offset(direction);
                        if (game_map->at(new_position)->is_empty())
                        {
                            game_map->at(new_position)->mark_unsafe(ship);
                            last_position[id] = ship->position;
                            cmd(ship->move(direction));
                            break;
                        }
                    }
                    continue;
                }
            }
            
            ship->last_position = last_position[id];
            auto dest = game_map->closest_dropoff(ship, me->dropoffs);
            if (!dest || ship->position.distance(dest) > ship->position.distance(me->shipyard->position))
                dest = me->shipyard->position;
            avg_halite = (avg_halite + game_map->at(ship)->halite) / 2;
            
            if (ship->position.distance(dest) == 0)
            {
                ship->return_to_shipyard = false;
            }

            if (ship->return_to_shipyard)
            {
                cmd(ship->move(game_map->naive_navigate(ship, dest)));
            }
            else 
            {
                if (game_map->at(ship)->halite < avg_halite || ship->is_full())
                {
                    if (ship->halite > ALMOST_FULL)
                    {
                        ship->return_to_shipyard = true;
                        last_position[id] = ship->position;
                        cmd(ship->move(game_map->naive_navigate(ship, dest)));
                    }
                    else
                    {                    
                        if (ship->halite >= game_map->at(ship->position)->halite / RATIO)
                        {
                            auto direction = game_map->best_cell(ship, map);
                            auto new_position = ship->position.directional_offset(direction);
                            game_map->at(new_position)->mark_unsafe(ship);
                            last_position[id] = ship->position;
                            cmd(ship->move(direction));
                        }
                        else 
                        {
                            cmd(ship->stay_still());
                        }
                    }
                }
                else
                {
                    cmd(ship->stay_still());
                }
            }
        }

        if (!game.end_turn(command_queue))
            break;
    }
}