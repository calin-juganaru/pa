#pragma once

#include "types.hpp"
#include "map_cell.hpp"

#include <vector>
#include <memory>
#include <unordered_map>

#define MAX_MOVES 7

namespace hlt
{
    struct GameMap
    {
        int width, height;
        std::vector<std::vector<MapCell>> cells;

        MapCell* at(const Position& position)
        {
            Position normalized = normalize(position);
            return &cells[normalized.y][normalized.x];
        }

        MapCell* at(const Entity& entity)
        {
            return at(entity.position);
        }

        MapCell* at(const Entity* entity)
        {
            return at(entity->position);
        }

        MapCell* at(const std::shared_ptr<Entity>& entity)
        {
            return at(entity->position);
        }

        int calculate_distance(const Position& source, const Position& target)
        {
            const auto& normalized_source = normalize(source);
            const auto& normalized_target = normalize(target);

            const int dx = std::abs(normalized_source.x - normalized_target.x);
            const int dy = std::abs(normalized_source.y - normalized_target.y);

            const int toroidal_dx = std::min(dx, width - dx);
            const int toroidal_dy = std::min(dy, height - dy);

            return toroidal_dx + toroidal_dy;
        }

        int calculate_distance(const std::shared_ptr<Entity>& source,
                               const std::shared_ptr<Entity>& target)
        {
            return calculate_distance(source->position, target->position);
        }

        Position normalize(const Position& position)
        {
            const int x = ((position.x % width) + width) % width;
            const int y = ((position.y % height) + height) % height;
            return { x, y };
        }

        std::vector<Direction> get_unsafe_moves(const Position& source, const Position& destination)
        {
            const auto& normalized_source = normalize(source);
            const auto& normalized_destination = normalize(destination);

            const int dx = std::abs(normalized_source.x - normalized_destination.x);
            const int dy = std::abs(normalized_source.y - normalized_destination.y);
            const int wrapped_dx = width - dx;
            const int wrapped_dy = height - dy;

            std::vector<Direction> possible_moves;

            if (normalized_source.x < normalized_destination.x) {
                possible_moves.push_back(dx > wrapped_dx ? Direction::WEST : Direction::EAST);
            } else if (normalized_source.x > normalized_destination.x) {
                possible_moves.push_back(dx < wrapped_dx ? Direction::WEST : Direction::EAST);
            }

            if (normalized_source.y < normalized_destination.y) {
                possible_moves.push_back(dy > wrapped_dy ? Direction::NORTH : Direction::SOUTH);
            } else if (normalized_source.y > normalized_destination.y) {
                possible_moves.push_back(dy < wrapped_dy ? Direction::NORTH : Direction::SOUTH);
            }

            return possible_moves;
        }

        Direction naive_navigate(std::shared_ptr<Ship> ship, const Position& destination)
        {
            for (auto direction : get_unsafe_moves(ship->position, destination))
            {
                Position target_pos = ship->position.directional_offset(direction);
                if (!at(target_pos)->is_occupied()
                    && target_pos != ship->last_position)
                {
                    at(target_pos)->mark_unsafe(ship);
                    return direction;
                }
            }

            return Direction::STILL;
        }

        void _update();
        static std::unique_ptr<GameMap> _generate();

        int halite_density(const Position& position)
        {
            auto halites = 0;
            for (auto&& x: {-3, -2, -1, 0, 1, 2, 3})
                for (auto&& y: {-3, -2, -1, 0, 1, 2, 3})
                    halites += this->at(position + Position(x, y))->halite;
            return halites / 49;
        }

        Direction best_cell(const std::shared_ptr<Ship>& ship, std::vector<std::vector<int>>& map)
        {
            auto max_halite = 0;
            auto best_direction = Direction::STILL;
            auto position = ship->position;

            for (auto&& direction: ALL_CARDINALS)
            {
                auto new_position = normalize(position.directional_offset(direction));
                if (!this->at(new_position)->is_occupied()
                    && new_position != ship->last_position
                    && map[new_position.x][new_position.y] < MAX_MOVES)
                {
                    auto halites = halite_density(new_position);
                    if (halites > max_halite)
                    {
                        max_halite = halites;
                        best_direction = direction;
                    }
                }
            }

            auto&& [x, y] = normalize(position.directional_offset(best_direction));
            map[x][y]++;

            return best_direction;
        }

        bool is_safe(const Position& position)
        {
            for (auto&& [x, y]: { std::pair{-1, -1}, {-1, 0}, {0, -1},
                        {1, 1}, {-1, 1}, {1, -1}, {0, 1}, {1, 0} })
                if (this->at(position + Position(x, y))->is_occupied())
                    return false;
            return true;
        }

        bool is_safe(const std::shared_ptr<Entity>& entity)
        {
            return is_safe(entity->position);
        }

        Direction safe_move(const std::shared_ptr<Ship>& ship, std::vector<std::vector<int>>& map)
        {
            for (auto&& direction: ALL_CARDINALS)
            {
                auto new_position = normalize(ship->position.directional_offset(direction));
                auto inverted_position = normalize(ship->position.directional_offset(invert_direction(direction)));

                if (this->at(new_position)->is_occupied()
                    || inverted_position == ship->last_position)
                    return invert_direction(direction);
                
                for (auto&& direction_2: ALL_CARDINALS)
                {
                    auto new_position_2 = new_position.directional_offset(direction_2);
                    auto inverted_direction_2 = invert_direction(direction_2);
                    
                    if (this->at(new_position_2)->is_occupied())
                        return inverted_direction_2;
                }
            }
            return Direction::STILL;
        }

        Position closest_dropoff(const std::shared_ptr<Ship>& ship, 
            std::unordered_map<int, std::shared_ptr<Dropoff>>& dropoffs)
        {
            auto closest = Position();
            auto min_dist = 1000000;

            for (auto&& [id, dropoff]: dropoffs)
            {
                auto dist = ship->position.distance(dropoff->position);
                if (dist < min_dist)
                {
                    min_dist = dist;
                    closest = dropoff->position;
                }
            }
            return closest;
        }
    };
}
