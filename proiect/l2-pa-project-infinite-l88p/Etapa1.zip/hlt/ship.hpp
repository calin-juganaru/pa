#pragma once

#include "entity.hpp"
#include "constants.hpp"
#include "command.hpp"

#include <memory>
#include <vector>

namespace hlt
{
    struct Ship: Entity
    {
        Halite halite;
        std::vector<Position> moves;
        bool return_to_shipyard;
        Position last_position;

        Ship(PlayerId player_id, EntityId ship_id, int x, int y, Halite halite):
            Entity(player_id, ship_id, x, y),
            halite(halite), return_to_shipyard(false) {}

        bool is_full() const
        {
            return halite >= constants::MAX_HALITE;
        }

        Command make_dropoff() const
        {
            return hlt::command::transform_ship_into_dropoff_site(id);
        }

        Command move(Direction direction)
        {
            return hlt::command::move(id, direction);
        }

        Command stay_still()
        {
            return hlt::command::move(id, Direction::STILL);
        }

        static std::shared_ptr<Ship> _generate(PlayerId player_id);
    };
}
